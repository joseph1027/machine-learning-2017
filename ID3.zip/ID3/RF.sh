#!/bin/bash
cd ../0316323
g++ -std=c++11 0316323_RF.cpp -o fff
./fff
